create function f(a bigint, b bigint DEFAULT 20, c bigint DEFAULT 10) returns bigint
    language sql
RETURN (a + b);

alter function f(bigint, bigint, bigint) owner to admin;

