create function f(a bigint, b bigint DEFAULT 42) returns bigint
    language sql
RETURN (a + b);

alter function f(bigint, bigint) owner to admin;

