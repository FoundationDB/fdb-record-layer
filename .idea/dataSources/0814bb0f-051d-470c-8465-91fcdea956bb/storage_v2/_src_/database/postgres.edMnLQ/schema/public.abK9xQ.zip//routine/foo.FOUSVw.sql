create function foo(col1 bigint)
    returns TABLE(x bigint, y bigint)
    language sql
as
$$select * from t1 where col1 < t1.col1$$;

alter function foo(bigint) owner to admin;

