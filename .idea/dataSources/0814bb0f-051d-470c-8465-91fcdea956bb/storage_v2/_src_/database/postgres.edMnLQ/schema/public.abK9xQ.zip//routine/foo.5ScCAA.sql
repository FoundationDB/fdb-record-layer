create function foo() returns integer
    language sql
as
$$select col1 from t1 where col1 < 42$$;

alter function foo() owner to admin;

