create function t1() returns integer
    language sql
as
$$select col1 from t1 where col1 < 42$$;

alter function t1() owner to admin;

